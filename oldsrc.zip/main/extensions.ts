/**
 * Extensions Manager
 * Handles importing, installing, enabling/disabling, and removing IDE extensions.
 * Extensions are stored in ~/.nexia-ide/extensions/ with a manifest.json each.
 */

import * as fs from 'fs';
import { execFileSync } from 'child_process';
import * as path from 'path';
import * as os from 'os';
import { spawn } from 'child_process';

export interface ExtensionManifest {
    id: string;
    name: string;
    version: string;
    author: string;
    description: string;
    type: 'tool' | 'template' | 'snippet' | 'theme' | 'library' | 'plugin';
    icon?: string;             // Emoji or path to icon
    homepage?: string;         // URL
    files?: string[];          // List of files included
    entryPoint?: string;       // Main script for plugins
    tags?: string[];
}

export interface InstalledExtension {
    manifest: ExtensionManifest;
    path: string;
    enabled: boolean;
    installedAt: string;       // ISO date
}

interface ExtensionsState {
    extensions: { [id: string]: { enabled: boolean; installedAt: string } };
}


/**
 * nexia-core.exe — the filesystem half of extension management.
 *
 * The split: C enumerates and moves bytes, TypeScript parses. nexia-core never
 * reads a manifest's contents — it reports the path and this side parses it,
 * so there is no second JSON reader to disagree with JSON.parse about escapes
 * or duplicate keys on files the IDE did not author.
 */
function corePath(): string {
    return path.join(__dirname, '..', 'nexia-core.exe');
}

function core(args: string[]): any {
    const out = execFileSync(corePath(), args, { encoding: 'utf8', windowsHide: true });
    return JSON.parse(out);
}
export class ExtensionManager {
    private extensionsDir: string;
    private stateFile: string;
    private state: ExtensionsState;
    private onOutput: ((data: string) => void) | null = null;

    constructor() {
        const nexiaDir = path.join(os.homedir(), '.nexia-ide');
        this.extensionsDir = path.join(nexiaDir, 'extensions');
        this.stateFile = path.join(nexiaDir, 'extensions-state.json');

        // Ensure directories exist
        fs.mkdirSync(this.extensionsDir, { recursive: true });

        // Load state
        this.state = this.loadState();
    }

    setOutputCallback(cb: (data: string) => void) {
        this.onOutput = cb;
    }

    private emit(msg: string) {
        if (this.onOutput) this.onOutput(msg);
    }

    private loadState(): ExtensionsState {
        try {
            if (fs.existsSync(this.stateFile)) {
                return JSON.parse(fs.readFileSync(this.stateFile, 'utf-8'));
            }
        } catch (e) {
            console.error('Failed to load extensions state:', e);
        }
        return { extensions: {} };
    }

    private saveState() {
        try {
            fs.writeFileSync(this.stateFile, JSON.stringify(this.state, null, 2));
        } catch (err: any) {
            this.emit(`Failed to save extensions state: ${err.message}\n`);
        }
    }

    /**
     * List all installed extensions.
     */
    getInstalled(): InstalledExtension[] {
        const results: InstalledExtension[] = [];
        let found: any[];
        try { found = core(['extensions', 'list']).extensions || []; }
        catch (e) { console.error('Failed to scan extensions directory:', e); return results; }

        for (const ext of found) {
            try {
                // ext.manifest is a path. nexia-core found it; JSON.parse reads it.
                const manifest: ExtensionManifest = JSON.parse(fs.readFileSync(ext.manifest, 'utf-8'));
                const stateEntry = this.state.extensions[manifest.id];
                results.push({
                    manifest,
                    path: ext.path,
                    enabled: stateEntry ? stateEntry.enabled : true,
                    installedAt: stateEntry ? stateEntry.installedAt : new Date().toISOString(),
                });
            } catch (e) {
                console.error(`Failed to parse manifest for extension "${ext.id}":`, e);
            }
        }
        return results.sort((a, b) => a.manifest.name.localeCompare(b.manifest.name));
    }

    /**
     * Install an extension from a folder path.
     * Copies the folder into the extensions directory.
     */
    async installFromFolder(folderPath: string): Promise<InstalledExtension> {
        const manifestPath = path.join(folderPath, 'manifest.json');
        if (!fs.existsSync(manifestPath)) {
            throw new Error('No manifest.json found in the selected folder.');
        }

        // Parsed here so the id is known before the copy; nexia-core is told
        // which id to install under rather than working it out itself.
        const manifest: ExtensionManifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
        if (!manifest.id || !manifest.name || !manifest.version) {
            throw new Error('Invalid manifest: requires id, name, and version fields.');
        }

        const res = core(['extensions', 'install', folderPath, manifest.id]);
        if (res.ok === false) throw new Error(res.error || 'Install failed.');

        this.state.extensions[manifest.id] = {
            enabled: true,
            installedAt: new Date().toISOString(),
        };
        this.saveState();
        this.emit(`✅ Installed extension: ${manifest.name} v${manifest.version}
`);

        return {
            manifest,
            path: res.path,
            enabled: true,
            installedAt: this.state.extensions[manifest.id].installedAt,
        };
    }

    /**
     * Install from a .zip file.
     * Extracts to a temp folder, then installs from there.
     */
    async installFromZip(zipPath: string): Promise<InstalledExtension> {
        const tempDir = path.join(os.tmpdir(), `nexia-ext-${Date.now()}`);
        fs.mkdirSync(tempDir, { recursive: true });

        try {
            // Use PowerShell to extract (Windows)
            await this.extractZip(zipPath, tempDir);

            // The zip might contain a single root folder or files directly
            const entries = fs.readdirSync(tempDir, { withFileTypes: true });
            let installDir = tempDir;

            // If there's a single folder inside, use that
            if (entries.length === 1 && entries[0].isDirectory()) {
                installDir = path.join(tempDir, entries[0].name);
            }

            // Check for manifest
            if (!fs.existsSync(path.join(installDir, 'manifest.json'))) {
                throw new Error('No manifest.json found in the extension package.');
            }

            return await this.installFromFolder(installDir);
        } finally {
            // Clean up temp
            try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
        }
    }

    /**
     * Uninstall an extension by ID.
     */
    uninstall(extensionId: string): boolean {
        // nexia-core removes the directory; the state file stays here, because
        // it is JSON and this side owns JSON.
        try {
            core(['extensions', 'uninstall', extensionId]);
        } catch (err: any) {
            this.emit(`Couldn't remove ${extensionId}: ${err.message}\n`);
            return false;
        }
        delete this.state.extensions[extensionId];
        this.saveState();
        this.emit(`🗑 Uninstalled extension: ${extensionId}\n`);
        return true;
    }

    /**
     * Enable or disable an extension.
     */
    setEnabled(extensionId: string, enabled: boolean): boolean {
        if (!this.state.extensions[extensionId]) {
            this.state.extensions[extensionId] = {
                enabled,
                installedAt: new Date().toISOString(),
            };
        } else {
            this.state.extensions[extensionId].enabled = enabled;
        }
        this.saveState();
        this.emit(`${enabled ? '✅' : '⏸'} ${extensionId} ${enabled ? 'enabled' : 'disabled'}\n`);
        return true;
    }

    /**
     * Get the extensions directory path.
     */
    getExtensionsDir(): string {
        try { return core(['extensions', 'dir']).path; }
        catch { return this.extensionsDir; }
    }

    /**
     * Open the extensions directory in the system file explorer.
     */
    openExtensionsDir() {
        // nexia-core opens it. Same ShellExecute either way; one caller.
        try { core(['extensions', 'open']); } catch {}
    }

    /**
     * Create a new extension template.
     */
    createTemplate(name: string, type: ExtensionManifest['type']): string {
        // nexia-core slugs the name and refuses the empty slug — a name with
        // nothing alphanumeric in it ("!!!", an emoji) once resolved to the
        // extensions root and scribbled manifest.json over it.
        const res = core(['extensions', 'template', name, type]);
        if (res.ok === false) {
            throw new Error(`"${name}" has no letters or numbers in it, so it can't be turned into an extension id. ` +
                `Give it a name with at least one letter or digit.`);
        }

        this.state.extensions[res.id] = {
            enabled: true,
            installedAt: new Date().toISOString(),
        };
        this.saveState();
        this.emit(`📦 Created extension template: ${name} at ${res.path}
`);
        return res.path;
    }



    private extractZip(zipPath: string, destDir: string): Promise<void> {
        return new Promise((resolve, reject) => {
            const ps = spawn('powershell.exe', [
                '-NoProfile', '-NonInteractive',
                '-Command', `Expand-Archive -Path '${zipPath.replace(/'/g, "''")}' -DestinationPath '${destDir.replace(/'/g, "''")}' -Force`
            ], { windowsHide: true });
            let stderr = '';
            ps.stderr.on('data', (d) => { stderr += d.toString(); });
            ps.on('close', (code) => {
                code === 0 ? resolve() : reject(new Error(`Zip extraction failed: ${stderr}`));
            });
            ps.on('error', reject);
        });
    }


}
