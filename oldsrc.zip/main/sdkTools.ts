/**
 * SDK Tools Integration
 * Provides access to shader compilation, audio encoding, XUI, and other SDK tools.
 */

import { spawn, execFileSync } from 'child_process';
import * as path from 'path';
import { Toolchain } from './toolchain';

export class SdkTools {
    private toolchain: Toolchain;
    private onOutput: ((data: string) => void) | null = null;

    constructor(toolchain: Toolchain) {
        this.toolchain = toolchain;
    }

    setOutputCallback(cb: (data: string) => void) {
        this.onOutput = cb;
    }

    private emit(data: string) {
        if (this.onOutput) this.onOutput(data);
    }

    /**
     * Launch an SDK tool from the tools panel.
     * GUI tools are spawned detached (no terminal output).
     * CLI tools run with stdout/stderr piped to the IDE terminal.
     */
    launchTool(toolName: string, isGui: boolean): Promise<string> {
        const toolPath = this.toolchain.getToolPath(toolName);
        if (!toolPath) {
            const msg = `${toolName} not found in SDK`;
            this.emit(`\nError: ${msg}\n`);
            return Promise.reject(new Error(msg));
        }

        const env = this.toolchain.getToolEnvironment();
        const toolDir = path.dirname(toolPath);

        if (isGui) {
            // GUI tool: launch detached, no output capture
            this.emit(`\nLaunching ${toolName}...\n`);
            try {
                spawn(toolPath, [], {
                    env,
                    cwd: toolDir,
                    detached: true,
                    stdio: 'ignore',
                    windowsHide: false,
                }).unref();
                this.emit(`${toolName} launched.\n`);
                return Promise.resolve(`${toolName} launched`);
            } catch (err: any) {
                this.emit(`Failed to launch ${toolName}: ${err.message}\n`);
                return Promise.reject(err);
            }
        } else {
            // CLI tool: run with output piped to terminal
            return this.runTool(toolName, []);
        }
    }

    /**
     * Run any SDK tool with arguments.
     */
    /**
     * Run any SDK tool with arguments.
     *
     * nexia-core does the spawn. It builds PATH, XEDK, INCLUDE and LIB itself
     * and passes the command line to CreateProcess unshelled — where this used
     * shell:true and hand-quoted the path, which is how
     * "C:Program Files (x86)..." becomes a bug: cmd.exe re-parses the line
     * and the parentheses are its own syntax.
     *
     * Output arrives once, at the end, rather than streaming. Every caller here
     * is a one-shot tool — fxc, xma2encode, xexdump — that prints a few lines and
     * exits, so nothing was watching it arrive. The build driver streams because
     * a build is long; these are not.
     */
    runTool(toolName: string, args: string[]): Promise<string> {
        return new Promise((resolve, reject) => {
            this.emit(`> ${toolName} ${args.join(' ')}\n`);
            try {
                const core = path.join(__dirname, '..', 'nexia-core.exe');
                const out = execFileSync(core, ['tool', 'run', toolName, ...args],
                    { encoding: 'utf8', windowsHide: true, maxBuffer: 32 * 1024 * 1024 });
                const res = JSON.parse(out);
                if (res.output) this.emit(res.output);
                if (res.ok) resolve(res.output || '');
                else reject(new Error(res.output || res.error || `${toolName} failed`));
            } catch (err: any) {
                // nexia-core exits non-zero when the tool does, and execFileSync
                // throws on that — the JSON on stdout is still the answer.
                if (err.stdout) {
                    try {
                        const res = JSON.parse(err.stdout);
                        if (res.output) this.emit(res.output);
                        reject(new Error(res.output || res.error || `${toolName} failed`));
                        return;
                    } catch {}
                }
                reject(err);
            }
        });
    }

    /**
     * Compile HLSL shader.
     */
    async compileShader(inputFile: string, outputFile: string, profile: string, entryPoint: string = 'main'): Promise<string> {
        this.emit(`\nCompiling shader: ${inputFile}\n`);
        const args = [
            `/T`, profile,
            `/E`, entryPoint,
            `/Fo`, outputFile,
            inputFile,
        ];
        return this.runTool('fxc.exe', args);
    }

    /**
     * Encode audio to XMA2.
     */
    async encodeAudioXma2(inputFile: string, outputFile: string): Promise<string> {
        this.emit(`\nEncoding audio (XMA2): ${inputFile}\n`);
        return this.runTool('xma2encode.exe', [inputFile, `/o`, outputFile]);
    }

    /**
     * Encode audio to xWMA.
     */
    async encodeAudioXwma(inputFile: string, outputFile: string): Promise<string> {
        this.emit(`\nEncoding audio (xWMA): ${inputFile}\n`);
        return this.runTool('xwmaencode.exe', [inputFile, outputFile]);
    }

    /**
     * Compile XUI skin.
     */
    async compileXui(inputFile: string, outputFile: string): Promise<string> {
        this.emit(`\nCompiling XUI: ${inputFile}\n`);
        return this.runTool('makexui.exe', [inputFile, `/o`, outputFile]);
    }

    /**
     * Inspect a binary (XEX dump).
     */
    async inspectBinary(inputFile: string): Promise<string> {
        this.emit(`\nInspecting: ${inputFile}\n`);
        return this.runTool('xexdump.exe', [inputFile]);
    }

    /**
     * Compress a file with LZX.
     */
    async compress(inputFile: string, outputFile: string): Promise<string> {
        this.emit(`\nCompressing: ${inputFile}\n`);
        return this.runTool('lzxcompress.exe', [inputFile, outputFile]);
    }

    /**
     * Build XEX image from executable.
     */
    async buildXex(inputFile: string, outputFile: string): Promise<string> {
        this.emit(`\nBuilding XEX: ${inputFile}\n`);
        return this.runTool('imagexex.exe', [`/nologo`, `/out:${outputFile}`, inputFile]);
    }

    /**
     * Launch PIX performance analyzer.
     */
    async launchPix(): Promise<void> {
        await this.launchTool('pix.exe', true);
    }
}
